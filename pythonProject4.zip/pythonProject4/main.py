
import os
import warnings
from abc import ABC, abstractmethod
from pathlib import Path

import torch
from bs4 import BeautifulSoup as bs
from PIL import Image

from src.unitable.trainer.utils import (VALID_BBOX_TOKEN, VALID_HTML_TOKEN)
from src.unitable.utils import (
    bbox_str_to_token_list, build_table_from_html_and_cell,
    html_str_to_token_list,
    html_table_template)
from src.unitable_utils import (autoregressive_decode, image_to_tensor, load_vocab_and_model, rescale_bbox)
from src.ocr.main import PaddleOCRModel

import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' before importing pyplot

warnings.filterwarnings('ignore')
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

MODEL_FILE_NAME = ["unitable_large_structure.pt", "unitable_large_bbox.pt", "unitable_large_content.pt"]
MODEL_DIR = Path("/pythonProject4/src/unitable/artifacts/")
VOCAB_DIR = Path("/pythonProject4/src/unitable/artifacts/vocab/")


class TableExtractorModel(ABC):
    @abstractmethod
    def __init__(self):
        """Initialize the table model from the given path."""
        self.table_structure_recognition_model = None
        self.table_cell_bbox_detection_model = None
        self.table_cell_content_extraction_model = None

    @abstractmethod
    def infer(self, image):
        """
        Perform inference on the given PIL image.
        Return extracted table content JSON
        """
        pass


class UniTableModel(TableExtractorModel):
    def __init__(self):
        """Initialize the table model from the given path."""
        self.table_structure_recognition_model = None
        self.table_structure_recognition_vocab = None
        self.table_cell_bbox_detection_model = None
        self.table_cell_bbox_detection_vocab = None
        self.table_cell_content_extraction_model = PaddleOCRModel()

        assert all([(MODEL_DIR / name).is_file() for name in MODEL_FILE_NAME]), "Please download model weights"

    def infer(self, image):
        """Perform inference on the given PIL image. Return extracted table content JSON"""
        if isinstance(image, str):
            image = Image.open(image).convert("RGB")
        image_size = image.size
        image_tensor = image_to_tensor(image, size=(448, 448))

        ############################################################
        # Table Structure Recognition
        ############################################################

        self.table_structure_recognition_vocab, self.table_structure_recognition_model = load_vocab_and_model(
            vocab_path=VOCAB_DIR / "vocab_html.json",
            max_seq_len=784,
            model_weights=MODEL_DIR / MODEL_FILE_NAME[0],
        )

        pred_html = autoregressive_decode(
            model=self.table_structure_recognition_model,
            image=image_tensor,
            prefix=[
                self.table_structure_recognition_vocab.token_to_id("[html]")],
            max_decode_len=512,
            eos_id=self.table_structure_recognition_vocab.token_to_id("<eos>"),
            token_whitelist=[self.table_structure_recognition_vocab.token_to_id(
                i) for i in VALID_HTML_TOKEN],
            token_blacklist=None
        )

        pred_html = pred_html.detach().cpu().numpy()[0]
        pred_html = self.table_structure_recognition_vocab.decode(
            pred_html, skip_special_tokens=False)
        pred_html = html_str_to_token_list(pred_html)

        ############################################################
        # Table Cell Bounding Box Detection
        ############################################################

        self.table_cell_bbox_detection_vocab, self.table_cell_bbox_detection_model = load_vocab_and_model(
            vocab_path=VOCAB_DIR / "vocab_bbox.json",
            max_seq_len=1024,
            model_weights=MODEL_DIR / MODEL_FILE_NAME[1],
        )

        pred_bbox = autoregressive_decode(
            model=self.table_cell_bbox_detection_model,
            image=image_tensor,
            prefix=[
                self.table_cell_bbox_detection_vocab.token_to_id("[bbox]")],
            max_decode_len=1024,
            eos_id=self.table_cell_bbox_detection_vocab.token_to_id("<eos>"),
            token_whitelist=[self.table_cell_bbox_detection_vocab.token_to_id(
                i) for i in VALID_BBOX_TOKEN[: 449]],
            token_blacklist=None
        )

        # Convert token id to token text
        pred_bbox = pred_bbox.detach().cpu().numpy()[0]
        pred_bbox = self.table_cell_bbox_detection_vocab.decode(
            pred_bbox, skip_special_tokens=False)

        pred_bbox = bbox_str_to_token_list(pred_bbox)
        pred_bbox = rescale_bbox(pred_bbox, src=(448, 448), tgt=image_size)

        ############################################################
        # Table Cell Content Extraction
        ############################################################

        image_crops = [image.crop(bbox) for bbox in pred_bbox]
        pred_cell = []

        for i, img in enumerate(image_crops):
            result = self.table_cell_content_extraction_model.infer_text_only(
                img)
            if result:
                pred_cell.append(result)
            else:
                pred_cell.append("")

        ############################################################
        # Combine the table structure and cell content
        ############################################################

        pred_code = build_table_from_html_and_cell(pred_html, pred_cell)
        pred_code = "".join(pred_code)
        pred_code = html_table_template(pred_code)

        # Display the HTML tables
        soup = bs(pred_code)
        table_code = soup.prettify()
        table_html = table_code
        return table_html


if __name__ == "__main__":
    image_dir = "/pythonProject4/src/data/"

    table_model = UniTableModel()

    image_path = os.listdir(image_dir)[2]

    result = table_model.infer(image_dir + image_path)
    print(result)
