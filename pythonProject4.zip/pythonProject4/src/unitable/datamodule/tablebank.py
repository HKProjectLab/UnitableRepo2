import os
from pathlib import Path
from typing import Any, Literal, Union

import torchvision.transforms as transforms
from PIL import Image
from torch.utils.data import Dataset


class TableBank(Dataset):
    """tablebank recognition"""

    def __init__(
            self,
            root_dir: Union[Path, str],
            label_type: Literal["image"],
            split: Literal["train", "val", "test"],
            transform: transforms = None,
    ) -> None:
        super().__init__()

        assert label_type == "image", "No annotations"

        self.root_dir = Path(root_dir)
        self.label_type = label_type
        self.transform = transform
        self.image_list = os.listdir(self.root_dir / "images")

        if split == "val" or split == "test":
            self.image_list = self.image_list[:1000]

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index: int) -> Any:
        name = self.image_list[index]
        img = Image.open(os.path.join(self.root_dir, "images", name))
        if self.transform:
            img = self.transform(img)

        if self.label_type == "image":
            return img
        else:
            raise ValueError("TableBank doesn't have HTML annotations.")
