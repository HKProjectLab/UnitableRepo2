from .train_beit import BeitTrainer
from .train_table import TableTrainer
from .train_vqvae import VqvaeTrainer
