import os
from abc import ABC, abstractmethod

import numpy as np
import pytesseract
from PIL import Image
from paddleocr import PaddleOCR


class OCRModel(ABC):
    @abstractmethod
    def __init__(self):
        """Initialize the OCR model"""
        self.ocr_model = None

    @abstractmethod
    def infer(self, image):
        """
        Perform inference on the given PIL image. 
        Return extracted content string
        """
        pass

    @abstractmethod
    def batch_infer(self, images):
        """
        Perform inference on the set of PIL images.
        Return list of extracted contents
        """
        pass

    @abstractmethod
    def infer_text_only(self, image):
        """
        Perform inference on the given PIL image. 
        Return extracted content string
        """
        pass

    @abstractmethod
    def batch_infer_text_only(self, images):
        """
        Perform inference on the set of PIL images.
        Return list of extracted contents
        """
        pass

    @abstractmethod
    def draw_bounding_boxes(self, image, result, save_dir=None):
        """Draw bounding boxes on the image based on inference results."""
        pass


class TesseractOCRModel(OCRModel):
    def __init__(self):
        """Initialize the OCR model"""
        self.ocr_model = pytesseract

    def infer(self, image):
        """Infer on PIL Image"""
        pass

    def batch_infer(self, images):
        """Infer on list of PIL Image"""
        pass

    def infer_text_only(self, image):
        """Infer only text content on PIL Image"""
        if isinstance(image, str):
            image = Image.open(image).convert("RGB")
        return self.ocr_model.image_to_string(image)

    def batch_infer_text_only(self, images):
        """Infer only text content on list of PIL Image"""
        pass

    def draw_bounding_boxes(self, image, result, save_dir=None):
        """Draw bounding boxes on the image based on inference results."""
        pass


class PaddleOCRModel(OCRModel):
    def __init__(self):
        """Initialize the OCR model"""
        self.ocr_model = PaddleOCR(
            use_angle_cls=True,
            lang='en',
            use_gpu=True
        )

    def infer(self, image):
        """Infer on PIL Image"""
        pass

    def batch_infer(self, images):
        """Infer on list of PIL Image"""
        pass

    def infer_text_only(self, image):
        """Infer only text content on PIL Image"""
        if isinstance(image, str):
            image = Image.open(image).convert("RGB")
        result = self.ocr_model.ocr(np.array(image), cls=True)
        text = ""
        if result:
            result = result[0]
            if result:
                txts = [line[1][0] for line in result]
                # scores = [line[1][1] for line in result]
                text = " ".join(txts)
        return text

    def batch_infer_text_only(self, images):
        """Infer only text content on list of PIL Image"""
        pass

    def draw_bounding_boxes(self, image, result, save_dir=None):
        """Draw bounding boxes on the image based on inference results."""
        pass


if __name__ == "__main__":
    image_dir = "src/data"
    save_dir = "src/results"

    text_model = TesseractOCRModel()

    image_path = os.listdir(image_dir)[0]
    res = text_model.infer_text_only(image_dir + image_path)
    print(res)
