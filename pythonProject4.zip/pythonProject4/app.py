
from main import UniTableModel

from io import BytesIO
from PIL import Image
from flask import Flask, request, jsonify

import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' before importing pyplot

app = Flask(__name__)

# Initialize the model
table_model = UniTableModel()


@app.route('/infer', methods=['POST'])
def infer():
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided"}), 400

    file = request.files['image']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    try:
        image = Image.open(BytesIO(file.read())).convert("RGB")
        result = table_model.infer(image)
        return jsonify({"table_html": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
