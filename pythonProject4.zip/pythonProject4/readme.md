
### Use Python 3.8 or later (3.8 recommended) to run the code. Please use conda environment for package management.
##### UniTable is a unified model designed for table structure recognition and extraction tasks. It processes tabular images, identifying the structure, extracting content, and determining cell bounding boxes. UniTable's key innovation is its use of self-supervised pretraining with a language-modeling objective, enabling it to perform multiple tasks like table structure recognition and content extraction in a streamlined manner. It excels in tasks like detecting table boundaries, recognizing cell positions, and processing multi-format tables, achieving state-of-the-art performance on major datasets.


### Overview
main.py is the main execution script for performing table extraction tasks using the UniTableModel. The script loads pre-trained models and performs table structure recognition, bounding box detection, and content extraction from tabular images.
app.py has Flask API endpoints for serving the model.

### Classes
1. TableExtractorModel (ABC)
Abstract base class defining the table extraction interface. It contains three abstract methods:

2. UniTableModel (TableExtractorModel)
Concrete implementation of TableExtractorModel. It uses three different models:

a. table_structure_recognition_model: Extracts the table structure.

b. table_cell_bbox_detection_model: Detects bounding boxes for cells.

c. table_cell_content_extraction_model: Extracts text from table cells using OCR.

### Methods
a. __init__()
Initializes UniTableModel and loads the model weights and vocabulary required for table structure recognition, bounding box detection, and content extraction.
Please download weights from the 

`https://huggingface.co/poloclub/UniTable/tree/main`
Download following three files and put them in src/unitable/artifacts/ folder:
1. unitable_large_structure.pt
2. unitable_large_bbox.pt
3. unitable_large_content.pt"

b. infer(image)
Performs inference on a single image:

1. Table Structure Recognition: Uses an autoregressive decoding approach to predict the table structure in HTML.
2. Bounding Box Detection: Detects bounding boxes around table cells.
3. Cell Content Extraction: Crops cell images and uses OCR to extract text.
Output: Combines the structure, bounding boxes, and content into an HTML table format.


### Documentation for unitable_utils.py
#### Overview
unitable_utils.py provides utility functions for model loading, image processing, and post-processing tasks in table extraction.

#### Functions
1. autoregressive_decode(model, image, prefix, max_decode_len, eos_id, token_whitelist, token_blacklist)
Performs autoregressive decoding for structure or bounding box detection by iteratively generating tokens from the image.

2. load_vocab_and_model(vocab_path, max_seq_len, model_weights)
Loads the tokenizer (vocabulary) and the pre-trained encoder-decoder model for table structure or bounding box detection.

3. image_to_tensor(image, size)
Converts a PIL image to a normalized PyTorch tensor for inference.

4. rescale_bbox(bbox, src, tgt)
Rescales bounding boxes from the original input size to the target output size.

#### Usage
Curl requests can be made to the Flask API endpoints defined in app.py to perform table extraction tasks. The API accepts image files and returns the extracted table in HTML format.

`curl -X POST -F "image=@img.png" http://0.0.0.0:5000/infer`

